package architecture;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import org.junit.jupiter.api.Test;

import static com.tngtech.archunit.library.Architectures.layeredArchitecture;

public class ArchitectureTest {

    @Test
    void verificarReglasDeCapas() {
        JavaClasses importedClasses = new ClassFileImporter()
                .importPackages("dao", "service", "ui");

        layeredArchitecture()
                .layer("UI").definedBy("ui..")
                .layer("Service").definedBy("service..")
                .layer("DAO").definedBy("dao..")

                .whereLayer("UI").mayOnlyAccessLayers("Service")
                .whereLayer("Service").mayOnlyAccessLayers("DAO")
                .whereLayer("DAO").mayNotAccessAnyLayer()

                .check(importedClasses);
    }
}
